# Programming Assignment 1.1

*[CEGM1000 MUDE](http://mude.citg.tudelft.nl/)*

*Written by: `<author(s)>`*

*Due: `<day of week>`, `<month>` `<day>`, `<year>`.*

You can access this assignment with the following link: `classroom.github.com/a/<xxxxxxx>`.

`<This repository contains source file for the assignment and will be used a source for student repositories and in the workbook. Replace this README with appropriate information describing the file types and how it should be submitted in case of a programming or workshop assignment.>`

> Copyright 2025 MUDE, Delft University of Technology. This work is licensed under a CC BY 4.0 License


# <...> Assignment <x.x>

# Part 1

**1.1 <question>**

% solution_start
`<solution>`
% solution_end

## Part `2, ...`

**2.1 <question>**

% solution_start
`<solution>`
% solution_end


> By `<author>`, Delft University of Technology. CC BY 4.0, more info [on the Credits page of Workbook](https://mude.citg.tudelft.nl/workbook-2025/credits.html).
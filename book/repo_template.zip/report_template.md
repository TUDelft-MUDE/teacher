# Programming Assignment 1.1

*[CEGM1000 MUDE](http://mude.citg.tudelft.nl/)*

*Written by: `<author(s)>`*

*Due: `<day of week>`, `<month>` `<day>`, `<year>`.*

# Part 1

**1.1 <question>**

% solution_start
`<solution>`
% solution_end

## Part `2, ...`

**2.1 <question>**

% solution_start
`<solution>`
% solution_end



*Copyright 2025 MUDE, TU Delft. This work is licensed under CC BY 4.0 License.*
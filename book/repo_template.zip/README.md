# <...> Assignment <x.x>

*Due: `<day of week>`, `<month>` `<day>`, `<year>`.*

You can access this assignment with the following link: `classroom.github.com/a/<xxxxxxx>`.

`<This repository contains source file for the assignment and will be used a source for student repositories and in the workbook. Replace this README with appropriate information describing the file types and how it should be submitted in case of a programming or workshop assignment.>`

> By `<author>`, Delft University of Technology. CC BY 4.0, more info [on the Credits page of Workbook](https://mude.citg.tudelft.nl/workbook-2025/credits.html).